# 表現当てゲーム Firebase接続済み版

Firebase設定を組み込み済みです。

次の作業：
1. index.html をWeb公開サービス（GitHub Pages等）にアップロード
2. 公開URLを友達に共有
3. Firebase Authentication の匿名ログインと Realtime Database が有効なら動作します

注意：
- 現在のRealtime Databaseルールがテストモードの場合、公開前にルールを安全な設定へ変更してください。
- ゲーム内のセリフ・表現の編集内容は現在、各端末のローカル保存です。
